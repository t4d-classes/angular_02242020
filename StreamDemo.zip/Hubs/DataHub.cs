﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using StreamDemo.Services;

namespace StreamDemo.Hubs
{
  public class DataHub : Hub
  {
    private TimerManager _timerManager;

    public DataHub(
      TimerManager timerManager
      )
    {
      _timerManager = timerManager;
    }

    public override Task OnConnectedAsync()
    {
      Console.WriteLine("Connecting to Hub");
      return base.OnConnectedAsync();
    }

    public override Task OnDisconnectedAsync(Exception exception)
    {
      Console.WriteLine("Disconnecting from Hub");
      _timerManager.Stop();
      return base.OnDisconnectedAsync(exception);
    }

    public async Task StartData()
    {
      _timerManager.Start();
    }

    public async Task StopData()
    {
      _timerManager.Stop();
    }

  }
}