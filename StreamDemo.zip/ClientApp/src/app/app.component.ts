import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import * as CanvasJS from '../assets/canvasjs.min';

import { DataService } from './services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {

  private dataSubcription: Subscription = undefined;
  private renderInterval: NodeJS.Timer = undefined;
  private dps: { x: number, y: number }[];
  private xVal: number;
  private dataLength: number;
  private chart: CanvasJS.Chart;

  public connected = false;
  public running = false;

  constructor(private dataSvc: DataService) { }

  ngOnInit() {


    this.dps = [];
    this.xVal = 200;
    this.dataLength = 200;

    for (let x = 0; x < this.xVal; x++) {
      this.dps.push({
        x,
        y: 50
      });
    }

    this.chart = new CanvasJS.Chart('chartContainer', {
      exportEnabled: false,
      axisY: {
        includeZero: false,
        maximum: 105,
        minimum: -5,
      },
      data: [{
        type: 'spline',
        markerSize: 0,
        dataPoints: this.dps,
      }],
    });

    this.chart.render();

  }

  ngOnDestroy() {
    if (this.dataSubcription) {
      this.dataSubcription.unsubscribe();
    }
    if (this.renderInterval) {
      clearInterval(this.renderInterval);
    }
    this.dataSvc.stopConnection();
  }

  connect() {
    this.dataSvc.startConnection().then(() => {
      this.connected = true;
    });
  }

  disconnect() {
    this.dataSvc.stopConnection().then(() => {
      this.connected = false;
    });
  }

  start() {

    this.renderInterval = setInterval(() => this.chart.render(), 100);

    this.dataSubcription = this.dataSvc.startData().subscribe((yVal: number) => {

      this.dps.push({
        x: this.xVal,
        y: yVal
      });
      this.xVal++;

      this.dps.splice(0, this.dps.length - this.dataLength);

    });

    this.running = true;
  }

  stop() {

    this.dataSvc.stopData();

    if (this.dataSubcription) {
      this.dataSubcription.unsubscribe();
    }
    if (this.renderInterval) {
      clearInterval(this.renderInterval);
    }

    this.running = false;

  }

}

