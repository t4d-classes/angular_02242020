import { Injectable } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { Observable, Subscriber } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private hubConnection: HubConnection;
  private hubConnectionPromise: Promise<HubConnection>;

  public startConnection() {
    this.hubConnection = new HubConnectionBuilder()
      .withUrl('/data')
      .build();

    this.hubConnectionPromise = new Promise((resolve, reject) => {

      this.hubConnection
      .start()
      .then(() => {
        console.log('Connection started');
        resolve();
      })
      .catch(err => {
        console.log('Error while starting connection: ' + err);
        reject();
      });

    });

    return this.hubConnectionPromise;

  }

  public stopConnection() {
    return this.hubConnection.stop().then(() => {
      console.log('Connection stopped');
    });
  }

  public startData() {
    return new Observable((subscriber: Subscriber<number>) => {

      this.hubConnection.on('NewData', (data: any) => {

        const num = Number(data);

        subscriber.next(num);

      });

      this.hubConnectionPromise.then(() => {
        this.hubConnection.invoke('StartData');
      });
    });
  }

  public stopData() {
    this.hubConnectionPromise.then(() => {
      this.hubConnection.invoke('StopData');
    });
  }
}
