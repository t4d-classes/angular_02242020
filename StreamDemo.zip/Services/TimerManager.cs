﻿using System;
using System.Threading;
using Microsoft.AspNetCore.SignalR;
using StreamDemo.Hubs;

namespace StreamDemo.Services
{
  public class TimerManager
  {
    private Random random = new Random();
    private Timer _timer;
    private AutoResetEvent _autoResetEvent;
    private Action _action;
 
    public TimerManager(IHubContext<DataHub> dataHub)
    {
      _action = () =>
      {
        var num = random.Next(0, 100);
        Console.WriteLine(num);
        dataHub.Clients.All.SendAsync("NewData", num);
      };
      _autoResetEvent = new AutoResetEvent(false);
    }
 
    public void Execute(object stateInfo)
    {
      _action();
    }

    public void Start()
    {
      _timer = new Timer(Execute, _autoResetEvent, 1000, 200);
    }

    public void Stop()
    {
      if (!(_timer is null))
      {
        _timer.Dispose();
        _timer = null;
      }
    }

  }
}